title: 记录一下搭建solo博客遇到的坑
date: '2019-09-19 14:21:51'
updated: '2019-09-19 14:23:31'
tags: [MySQL安装]
permalink: /articles/2019/09/19/1568874111832.html
---
## 目录	
* [配置MySQL](http://pinmua.cn/articles/2019/09/19/1568874111832.html)
* 安装docker（暂未更新）
* 获取solo镜像（暂未更新）
* 创建容器并运行（暂未更新）

### 一、安装Mysql。
	由于购买的是阉割版的腾讯云服务器，所以下载速度贼慢，于是我们通过去MySQL官网下载安装包，然后通过XFTP上传到服务器安装快一些。

**1.下载 4个rpm包**

mysql-community-client-5.7.26-1.el7.x86_64.rpm  
mysql-community-common-5.7.26-1.el7.x86_64.rpm  
mysql-community-libs-5.7.26-1.el7.x86_64.rpm  
mysql-community-server-5.7.26-1.el7.x86_64.rpm



mysql官网：[https://dev.mysql.com/downloads/mysql/5.7.html#downloads](https://dev.mysql.com/downloads/mysql/5.7.html#downloads)



在官网找到对应的版本：

![](https://img2018.cnblogs.com/blog/1665018/201906/1665018-20190602135600273-370296165.png)

点击直接下载：

![](https://img2018.cnblogs.com/blog/1665018/201906/1665018-20190602135850057-241341118.png)

 

如果嫌麻烦的话，下面给出了4个myql5.7 的rpm包的路径，直接打开迅雷填入下载路径就可以进行下载，其他版本可以用同样方法：

 https://cdn.mysql.com//Downloads/MySQL-5.7/mysql-community-server-5.7.26-1.el7.x86_64.rpm

 https://cdn.mysql.com//Downloads/MySQL-5.7/mysql-community-client-5.7.26-1.el7.x86_64.rpm

 https://cdn.mysql.com//Downloads/MySQL-5.7/mysql-community-common-5.7.26-1.el7.x86_64.rpm

 https://cdn.mysql.com//Downloads/MySQL-5.7/mysql-community-libs-5.7.26-1.el7.x86_64.rpm

 

**2.上传rpm到linux**

我这里用的xshell，没有安装xftp

![](https://img2018.cnblogs.com/blog/1665018/201906/1665018-20190602141607431-1311362884.png)

 

在sftp输入 put命令，选择下载好的rpm包即可上传：

![](https://img2018.cnblogs.com/blog/1665018/201906/1665018-20190602141855363-606830024.png)

 

**3.安装**

已经上传好的rpm如下：

![](https://img2018.cnblogs.com/blog/1665018/201906/1665018-20190602142028283-372433065.png)



安装顺序 common-->libs-->client-->server

```
   rpm -ivh mysql-community-common-5.7.22-1.el7.x86_64.rpm 
   rpm -ivh mysql-community-libs-5.7.22-1.el7.x86_64.rpm 
   rpm -ivh mysql-community-client-5.7.22-1.el7.x86_64.rpm 
   rpm -ivh mysql-community-server-5.7.22-1.el7.x86_64.rpm 
```




如果执行第二条命令，出现错误,请卸载相关组件

```
	[root@VM_0_11_redhat tools]# rpm -qa | grep postfix
	postfix-2.10.1-6.el7.x86_64
	[root@VM_0_11_redhat tools]#  rpm -qa | grep mariadb
	mariadb-libs-5.5.52-1.el7.x86_64
	[root@VM_0_11_redhat tools]# rpm -ev postfix-2.10.1-6.el7.x86_64
	Preparing packages...
	postfix-2:2.10.1-6.el7.x86_64
	[root@VM_0_11_redhat tools]# rpm -ev mariadb-libs-5.5.52-1.el7.x86_64
	Preparing packages...
	mariadb-libs-1:5.5.52-1.el7.x86_64
```
如果执行第四条命令出现错误

错误原因：缺少libnuma相关的包依赖

 解决方案： 
 ```
yum install libnuma*
```




** 4.配置**

启动mysql服务 ：

```
[root@localhost ~]# service mysqld start  
Redirecting to /bin/systemctl start mysqld.service  
[root@localhost ~]#
```

找到初始密码：

```
[root@localhost ~]# cat /var/log/mysqld.log |grep password  
2019-06-02T08:39:38.448115Z 1 [Note] A temporary password is generated for root@localhost: dLZMCRv?s2q)  
2019-06-02T08:40:41.870130Z 2 [Note] Access denied for user 'root'@'localhost' (using password: NO)
```

登陆mysql：

```
[root@localhost ~]# mysql -u root -p
```

密码为上面找到的dLZMCRv?s2q)

修改root密码：

```
mysql> alter user 'root'@'localhost' identified by 'newpasswd';
```

允许远程连接：

```
mysql> GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY 'newpasswd' WITH GRANT OPTION;
```


 
---> ————————————————
版权声明：本文为CSDN博主「郑浩-」的原创文章，遵循 CC 4.0 BY-SA 版权协议，转载请附上原文出处链接及本声明。
原文链接：https://blog.csdn.net/hao134838/article/details/80163181
